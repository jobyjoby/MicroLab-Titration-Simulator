using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class TitrationManager : MonoBehaviour
{
    public enum Step
    {
        Start,
        FillBurette,
        SetInitial,
        AddIndicator,
        Titrating,
        Completed
    }

    public Step currentStep;


    public TMP_Text stepText;
    public TMP_Text resultText;


    public float buretteVolume = 50f;
    public float flaskVolume = 0f;
    public float usedVolume = 0f;


    public float flowRate = 0f;


    public float initialReading = 0f;
    public float finalReading = 0f;


    public float endpointThreshold = 18.6f;
    private bool isCompleted = false;


    private bool initialSetDone = false;
    private bool indicatorAdded = false;


    public Renderer flaskRenderer;

    void Start()
    {
        currentStep = Step.Start;
        UpdateUI();
    }

    void Update()
    {
        if (currentStep == Step.Titrating && !isCompleted && flowRate > 0)
        {
            float delta = flowRate * Time.deltaTime * 5f;

            buretteVolume -= delta;
            flaskVolume += delta;
            usedVolume += delta;

            buretteVolume = Mathf.Clamp(buretteVolume, 0, 50);

            CheckEndpoint();
        }
    }

    public void StartExperiment()
    {
        if (currentStep == Step.Start)
        {
            currentStep = Step.FillBurette;
            UpdateUI();
        }
    }

    public void NextStep()
    {
        if (currentStep == Step.FillBurette)
        {
            // Auto fill when entering step
            buretteVolume = 50f;

            currentStep = Step.SetInitial;
        }
        else if (currentStep == Step.SetInitial)
        {
            if (!initialSetDone)
            {
                Debug.Log("Please set initial reading first!");
                return;
            }

            currentStep = Step.AddIndicator;
        }
        else if (currentStep == Step.AddIndicator)
        {
            if (!indicatorAdded)
            {
                Debug.Log("Please add indicator first!");
                return;
            }

            currentStep = Step.Titrating;
        }

        UpdateUI();
    }



    public void SetInitialReading()
    {
        if (currentStep == Step.SetInitial)
        {
            initialReading = buretteVolume;
            initialSetDone = true;

            Debug.Log("Initial Reading: " + initialReading);
        }
    }

    public void AddIndicator()
    {
        if (currentStep == Step.AddIndicator)
        {
            indicatorAdded = true;

            Debug.Log("Indicator Added");
        }
    }

    public void SetFlowRate(float value)
    {
        flowRate = value;
    }



    void CheckEndpoint()
    {
        if (usedVolume >= endpointThreshold && !isCompleted)
        {
            isCompleted = true;

            finalReading = buretteVolume;

            flaskRenderer.material.color = Color.magenta;

            currentStep = Step.Completed;
            UpdateUI();
        }
    }


    void UpdateUI()
    {
        switch (currentStep)
        {
            case Step.Start:
                stepText.text = "Click Start to Begin";
                resultText.text = "";
                break;

            case Step.FillBurette:
                stepText.text = "Step 1: Click Next to Fill Burette";
                break;

            case Step.SetInitial:
                stepText.text = "Step 2: Click Set Initial Reading";
                break;

            case Step.AddIndicator:
                stepText.text = "Step 3: Click Add Indicator";
                break;

            case Step.Titrating:
                stepText.text = "Step 4: Adjust Flow using Slider";
                break;

            case Step.Completed:
                stepText.text = "Titration Completed";

                float volumeUsed = initialReading - finalReading;

                resultText.text =
                    "Initial: " + initialReading.ToString("F2") + " mL\n" +
                    "Final: " + finalReading.ToString("F2") + " mL\n" +
                    "Used: " + volumeUsed.ToString("F2") + " mL";
                break;
        }
    }



    public void ResetSimulation()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}